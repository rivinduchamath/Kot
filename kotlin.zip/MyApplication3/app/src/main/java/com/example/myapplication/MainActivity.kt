package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import com.example.myapplication.configuration.DatabaseHelper
import com.example.myapplication.model.CustomerModel
import com.example.myapplication.util.Utility

class MainActivity : AppCompatActivity() {

    private lateinit var editName: EditText
    private lateinit var editEmail: EditText
    private lateinit var editPassword: EditText
    private lateinit var editTel: EditText
    private lateinit var editDob: EditText
    private lateinit var editAddress: EditText
    private lateinit var type: EditText
    private lateinit var buttonSave: Button
    private lateinit var imageViewRegister: ImageView

 private lateinit var sqlLiteHelper : DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register_as_customer)

        intView()

        sqlLiteHelper = DatabaseHelper(this)

        buttonSave.setOnClickListener { addCustomer() }
        imageViewRegister.setOnClickListener { backToLogin() }
    }

    private fun backToLogin() {
        imageViewRegister.setOnClickListener (

            View.OnClickListener { startActivity(Intent(this,LoginActivity::class.java))  }
        )
    }

    private fun getCustomers(){
        val customerList = sqlLiteHelper.getAllCustomers()
        Log.e("Get Customer", "${customerList.size}")
    }

    private fun addCustomer() {
        val name = editName.text.toString()
        val email = editEmail.text.toString()
        val address = editAddress.text.toString()
        val type = type.text.toString()
        val password = editPassword.text.toString()
        val tel = ""
        val dob = ""

        if(name.isEmpty() || email.isEmpty() || address.isEmpty() || password.isEmpty()){
            Toast.makeText(this, "Please Enter All Fields...", Toast.LENGTH_SHORT).show()
        }else{
            val cus = CustomerModel( name = name, email = email, password = password,
                tel = tel , dob = dob , address = address, type = type)
            val status = sqlLiteHelper.insertCustomer(cus)

            if(status > -1){

                Toast.makeText(this, "Login Success...", Toast.LENGTH_SHORT).show()
                Utility.myStaticData(name, email,tel,address);

                Toast.makeText(this, "Customer Added...", Toast.LENGTH_SHORT).show()
                clearData()
                startActivity(Intent(this,DashboardActivity::class.java))
            }else{
                Toast.makeText(this, "Customer Not Added...", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun clearData() {
        editName.setText("")
        editEmail.setText("")
        editAddress.setText("")
        editPassword.setText("")
        type.setText("")
        editName.requestFocus()
    }

    private fun intView() {
        editName = findViewById(R.id.editTextTextPersonName2)
        editAddress = findViewById(R.id.editTextTextPersonName3)
        editPassword = findViewById(R.id.editTextTextPersonName4)
        type = findViewById(R.id.type)
        editEmail = findViewById(R.id.editTextTextPersonName5)
        buttonSave = findViewById(R.id.button2)
        imageViewRegister = findViewById(R.id.imageViewRegister)
    }
}