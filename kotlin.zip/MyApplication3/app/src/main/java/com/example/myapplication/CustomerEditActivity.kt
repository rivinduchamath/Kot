package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.configuration.DatabaseHelper
import com.example.myapplication.model.CustomerModel
import com.example.myapplication.util.Utility

class CustomerEditActivity : AppCompatActivity() {

    private lateinit var name: EditText
    private lateinit var phoneNumber: EditText
    private lateinit var address: EditText
    private lateinit var buttonSave: Button


    private lateinit var sqlLiteHelper: DatabaseHelper


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.customer_edit)
        intView()

        sqlLiteHelper = DatabaseHelper(this)

        name.setText(Utility.getLoggedCustomerName())
        phoneNumber.setText(Utility.getLoggedCustomerTel())
        address.setText(Utility.getLoggedCustomerAddress())

        buttonSave.setOnClickListener { updateCustomer() }

    }

    @SuppressLint("Range")
    private fun updateCustomer() {
        val name = name.text.toString()
        val tel = phoneNumber.text.toString()
        val address = address.text.toString()

        if (Utility.getLoggedCustomerEmail() != "") {
            val args = listOf<String>(Utility.getLoggedCustomerEmail()).toTypedArray()

            val loginCustomer = sqlLiteHelper.getCustomerData(args)

            if(loginCustomer.moveToNext()) {
                var id = loginCustomer.getInt(loginCustomer.getColumnIndex("id"))
                var email = loginCustomer.getString(loginCustomer.getColumnIndex("email"))
                var password = loginCustomer.getString(loginCustomer.getColumnIndex("password"))
                var dob = loginCustomer.getString(loginCustomer.getColumnIndex("dob"))
                var type = loginCustomer.getString(loginCustomer.getColumnIndex("type"))

                val cus = CustomerModel(type = type, id= id ,dob = dob,password = password, email =email , name = name, tel = tel, address = address)
                val status = sqlLiteHelper.update(cus)
                if(status > -1){

                    Toast.makeText(this, "Update Success...", Toast.LENGTH_SHORT).show()
                    Utility.myStaticData(name, email, tel, address);
                    startActivity(Intent(this,DashboardActivity::class.java))
                }else{
                    Toast.makeText(this, "Customer Not Updated...", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this, "Something Went Wrong...", Toast.LENGTH_SHORT).show()
        }


    }

    private fun intView() {
        name = findViewById(R.id.editTextTextPersonName11)
        phoneNumber = findViewById(R.id.editTextTextPersonName12)
        address = findViewById(R.id.editTextTextPersonName13)
        buttonSave = findViewById(R.id.button)


    }
}