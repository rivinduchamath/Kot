package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.configuration.DatabaseHelper
import com.example.myapplication.util.Utility

class LoginActivity : AppCompatActivity()  {
    private lateinit var buttonRegister: Button
    private lateinit var button4: Button
    private lateinit var editTextTextPersonName16: EditText
    private lateinit var editTextTextPersonName17: EditText

//    var helper = DatabaseHelper(applicationContext)

    private lateinit var sqlLiteHelper : DatabaseHelper
//    var db = sqlLiteHelper.readableDatabase


    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.customer_login)
        intView()
        buttonRegister.setOnClickListener ( View.OnClickListener { startActivity(Intent(this,MainActivity::class.java))  })
        sqlLiteHelper = DatabaseHelper(this)
        button4.setOnClickListener {


            val args = listOf<String>(editTextTextPersonName16.text.toString(), editTextTextPersonName17.text.toString()).toTypedArray()
            val loginCustomer = sqlLiteHelper.loginCustomer(args)
            if(loginCustomer.moveToNext()){

               var id= loginCustomer.getInt(loginCustomer.getColumnIndex("id"))
               var name= loginCustomer.getString(loginCustomer.getColumnIndex("name"))
               var email= loginCustomer.getString(loginCustomer.getColumnIndex("email"))
               var address= loginCustomer.getString(loginCustomer.getColumnIndex("address"))
               var tel= loginCustomer.getString(loginCustomer.getColumnIndex("tel"))

                Toast.makeText(this, "Login Success...", Toast.LENGTH_SHORT).show()
                Utility.myStaticData(name, email,tel,address);
                startActivity(Intent(this,DashboardActivity::class.java))
            }else{
                Toast.makeText(this, "Login Fail...", Toast.LENGTH_SHORT).show()
                clearData()
            }
        }

    }

    private fun clearData() {
        editTextTextPersonName16.setText("")
        editTextTextPersonName17.setText("")

    }

    private fun intView() {
        buttonRegister = findViewById(R.id.register)
        button4 = findViewById(R.id.button4)
        editTextTextPersonName16 = findViewById(R.id.editTextTextPersonName16)
        editTextTextPersonName17 = findViewById(R.id.editTextTextPersonName17)
    }
}