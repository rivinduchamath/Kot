package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.configuration.DatabaseHelper
import com.example.myapplication.util.Utility

class DeleteActivity : AppCompatActivity() {

    private lateinit var button3: Button
    private lateinit var editTextTextPersonName14: EditText
    private lateinit var editTextTextPersonName15: EditText
    private lateinit var sqlLiteHelper : DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.customer_delete)
        intView()
        sqlLiteHelper = DatabaseHelper(this)

        button3.setOnClickListener {



            val loginCustomer = sqlLiteHelper.deleteCustomer(editTextTextPersonName14.text.toString(), editTextTextPersonName15.text.toString())
            if(loginCustomer > -1){
                Toast.makeText(this, "Delete Success...", Toast.LENGTH_SHORT).show()
                Utility.myStaticData( "","","","");
                startActivity(Intent(this,LoginActivity::class.java))
            }else{
                Toast.makeText(this, "Delete Fail...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun intView() {
        button3 = findViewById(R.id.button3)
        editTextTextPersonName14 = findViewById(R.id.editTextTextPersonName14)
        editTextTextPersonName15 = findViewById(R.id.editTextTextPersonName15)
    }
}