package com.example.myapplication.model

import java.util.*

data class CustomerModel(
    var id: Int = getAutoIncrement(),
    var name: String = "",
    var email: String = "",
    var password: String = "",
    var tel: String = "",
    var dob: String = "",
    var address: String = "",
    var type: String = ""

) {

    companion object {
        fun getAutoIncrement(): Int {
            val random = Random()
            return random.nextInt(100000)
        }
    }

}