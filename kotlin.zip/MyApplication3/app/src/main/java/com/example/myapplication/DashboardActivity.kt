package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.configuration.DatabaseHelper
import com.example.myapplication.util.Utility

class DashboardActivity : AppCompatActivity()  {
    private lateinit var buttonDelete: Button
    private lateinit var buttonLogOut: Button
    private lateinit var buttonEdit: Button
    private lateinit var welcomeText: TextView
    private lateinit var names: TextView


    private lateinit var sqlLiteHelper : DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard_activity)
        intView()
        buttonDelete.setOnClickListener ( View.OnClickListener { startActivity(Intent(this,DeleteActivity::class.java))  })
        buttonLogOut.setOnClickListener (
            View.OnClickListener { startActivity(Intent(this,LoginActivity::class.java))  }
        )
        buttonEdit.setOnClickListener ( View.OnClickListener { startActivity(Intent(this,CustomerEditActivity::class.java))  })

    if(Utility.getLoggedCustomerEmail() != "")
         welcomeText.setText(Utility.getLoggedCustomerEmail())

    }


    private fun intView() {
        buttonDelete = findViewById(R.id.deleteUser)
        buttonLogOut = findViewById(R.id.logOut)
        buttonEdit = findViewById(R.id.editUser)
        welcomeText = findViewById(R.id.welcomeText)
        names = findViewById(R.id.names)
    }
}