package com.example.myapplication.util

import com.example.myapplication.model.CustomerModel

class Utility {
    companion object{

        lateinit var customer : CustomerModel;
        fun myStaticData ( name: String, email: String , tel :String , address : String): CustomerModel{
            val cus = CustomerModel(address = address , tel =  tel, name = name, email = email)
            customer = cus
            return customer;
        }

        fun getLoggedCustomerEmail(): String {
           return customer.email;
        }
        fun getLoggedCustomerAddress(): String {
            return customer.address;
        }
        fun getLoggedCustomerTel(): String {
            return customer.tel;
        }
        fun getLoggedCustomerName(): String {
            return customer.name;
        }
    }
}