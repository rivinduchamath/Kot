package com.example.myapplication.configuration;

import android.annotation.SuppressLint
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.myapplication.model.CustomerModel


class DatabaseHelper (context: Context) :

        SQLiteOpenHelper (context, DATABASE_NAME, null , DATABASE_VERSION){

        companion object{
                private const val DATABASE_VERSION = 1;
                private const val DATABASE_NAME = "customerss1.db";
                private const val TABLE_CUSTOMER = "tbl_customer";
                private const val ID = "id"
                private const val NAME = "name"
                private const val EMAIL = "email"
                private const val PASSWORD = "password"
                private const val DOB = "dob"
                private const val TEL = "tel"
                private const val ADDRESS = "address"
                private const val USERTYPE = "type"
        }

        override fun onCreate(db: SQLiteDatabase?) {
                val createTableCustomer = ("CREATE TABLE "+ TABLE_CUSTOMER+ "("
                + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + NAME + " TEXT,"
                + EMAIL + " TEXT," + PASSWORD + " TEXT," + DOB + " TEXT," + TEL + " TEXT," + USERTYPE + " TEXT,"+ ADDRESS + " TEXT," +" UNIQUE ("+ EMAIL+")"  + ")")
                db?.execSQL(createTableCustomer)
        }

        override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

                db!!.execSQL("DROP TABLE IF EXISTS $TABLE_CUSTOMER")
                onCreate(db)
        }
      fun insertCustomer(cus : CustomerModel ): Long{
              val db = this.writableDatabase

              val  contentValues  = ContentValues()
              contentValues.put(ID,cus.id)
              contentValues.put(NAME,cus.name)
              contentValues.put(EMAIL,cus.email)
              contentValues.put(PASSWORD,cus.password)
              contentValues.put(TEL,cus.tel)
              contentValues.put(DOB,cus.dob)
              contentValues.put(ADDRESS,cus.address)
              contentValues.put(USERTYPE,cus.type)

              val success = db.insert(TABLE_CUSTOMER, null ,contentValues)
              db.close()
              return success
      }



@SuppressLint("Range", "SuspiciousIndentation")
fun getAllCustomers() : ArrayList<CustomerModel>{
                val customerList: ArrayList<CustomerModel> = ArrayList()
                val selectQuery = " SELECT * FROM $TABLE_CUSTOMER"
                val db = this.readableDatabase

                val cursor: Cursor?
                try {
                    cursor = db.rawQuery(selectQuery, null)

                }catch (e : Exception){
                        e.printStackTrace()
                        db.execSQL(selectQuery)
                        return ArrayList()
                }
                var id : Int
                var  name : String
                var email : String
                var password : String
                var tel : String
                var address : String
                var dob : String
                var type : String

                if(cursor.moveToFirst()){
                        do {
                            id = cursor.getInt(cursor.getColumnIndex("id"))
                                name = cursor.getString(cursor.getColumnIndex("name"))
                                email = cursor.getString(cursor.getColumnIndex("email"))
                                password = cursor.getString(cursor.getColumnIndex("password"))
                                tel = cursor.getString(cursor.getColumnIndex("tel"))
                                address = cursor.getString(cursor.getColumnIndex("address"))
                                dob = cursor.getString(cursor.getColumnIndex("dob"))
                            type = cursor.getString(cursor.getColumnIndex("type"))
                        val cus = CustomerModel(id = id, name = name, email = email, password = password,
                                tel = tel , dob = dob , address = address,type =type)
                                customerList.add(cus);
                        }while (cursor.moveToNext())
                }
                return customerList
        }

    fun loginCustomer(args: Array<String>):Cursor {
        val db = this.writableDatabase
        var rs = db.rawQuery(" SELECT * FROM tbl_customer WHERE email = ? AND password =?", args)
          return rs
    }

    fun deleteCustomer(email: String, password: String): Int {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(EMAIL , email)
        contentValues.put(PASSWORD , password)
        try {
            var rs = db.delete(TABLE_CUSTOMER,"email=$EMAIL AND password = $PASSWORD",null)

            return rs

        }catch (e : Exception){
            return 0;
        }
        }

    fun update(cus: CustomerModel): Int {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(EMAIL , cus.email)
        contentValues.put(PASSWORD , cus.password)
        contentValues.put(ID , cus.id)
        contentValues.put(NAME , cus.name)
        contentValues.put(ADDRESS , cus.address)
        contentValues.put(DOB , cus.dob)
        contentValues.put(TEL , cus.tel)
        contentValues.put(USERTYPE , cus.type)
        val args = listOf<String>(cus.email).toTypedArray()

        val success = db.update(TABLE_CUSTOMER, contentValues,"email=?" ,args)
        db.close()
        return success
    }

    fun getCustomerData(loggedCustomerEmail: Array<String>): Cursor {
        val db = this.writableDatabase
        var rs = db.rawQuery(" SELECT * FROM tbl_customer WHERE email =?", loggedCustomerEmail)
        return rs
    }


}